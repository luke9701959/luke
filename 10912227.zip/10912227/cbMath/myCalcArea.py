''' myCalcArea '''
PI = 3.1415
def RectArea( w, l):
  return w * l
def TriArea( s, h):
  return s * h / 2
def SquareArea( s):
  return s * s;
def CircleArea( r ):
  return PI * r * r
