# 1092I2CSHW1
這個作業要大家練習自製一個 Python 的套件，套件名稱是 myMath，當中包含的模組有 myArithmetic.py、myCalcArea.py、myStatistics.py。請參閱資料夾中的檔案。
製作好專案後，請大家再創創建一個 main.py 檔，當中引用了這個自製套件 myMath，並利用當中的模組來計算使用者輸入的五個數值的平均值，並列印出來。
